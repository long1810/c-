﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Đặng_Hoàng_Long
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_dangnhap_Click(object sender, EventArgs e)
        {
            String con_tr = @"Data Source=Admin-PC0910rdk\SQLEXPRESS;Initial Catalog=QLNV;Integrated Security=True";


           SqlConnection conn = new SqlConnection(con_tr);
           conn.Open();

           string tk = txt_userName.Text;
           string mk = txt_pass.Text;

           string query = "select COUNT(*) from NhanVien where MaNV ='"+tk+"' and MatKhau='"+mk+"' ";
           SqlCommand cmd = new SqlCommand(query, conn);
            //thuc thi 
           int soluong = int.Parse(cmd.ExecuteScalar().ToString());

            
            
            conn.Close();
            if (soluong == 0)
            {
                MessageBox.Show("tài khoản hay mật khẩu sai");
            }
            else {
                MessageBox.Show("thanh cong ");
                Form2 f = new Form2();
                f.ShowDialog();
                this.Hide();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
