﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Đặng_Hoàng_Long
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btn_them_Click(object sender, EventArgs e)
        {
            String con_tr = @"Data Source=Admin-PC0910rdk\SQLEXPRESS;Initial Catalog=QLNV;Integrated Security=True";
            

            SqlConnection conn = new SqlConnection(con_tr);
            conn.Open();

            string tk = txt_mk.Text;
            string mk = txt_mk.Text;
            string tenNV = txt_tenNV.Text;
            string quequan = txt_quequan.Text;
            bool gioitinh;
            if (rab_nam.Checked)
            {
                gioitinh = true;
            }
            else if(rab_nu.Checked)
            {
                gioitinh = false;
            }
            

            string query = "INSERT [dbo].[NhanVien] ([MaNV], [MatKhau], [TenNV], [QueQuan], [GioiTinh]) VALUES (N'"+tk+"', N'"+mk+"', N'"+tenNV+"', N'"+quequan+"',0) ";
            string query = "INSERT [dbo].[NhanVien] ( [GioiTinh]) VALUES () ";
            SqlCommand cmd = new SqlCommand(query, conn);
            //thuc thi 
            cmd.ExecuteNonQuery();



            conn.Close();
        }
    }
}
